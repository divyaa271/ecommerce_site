import React, { useContext } from 'react';
import './CartItems.css';
import { ShopContext } from '../../Context/ShopContext';
import remove_icon from '../Assets/cart_cross_icon.png';

const CartItems = () => {
    const { all_product, CartItems, removeFromCart } = useContext(ShopContext);

    return (
        <div className='cartitems'>
            <div className='cartitems_format_main'>
                <p>Product</p>
                <p>Title</p>
                <p>Price</p>
                <p>Quantity</p>
                <p>Total</p>
                <p>Remove</p>
            </div>
            <hr />

            {all_product && Array.isArray(all_product) ? (
                all_product.map((e) => {
                    if (CartItems && CartItems[e.id] && CartItems[e.id] > 0) 
                        {
                        return<div>
                                <div className='cartitems_format'>
                                    <img src={e.image} alt='' className='carticon_product_icon' />
                                    <p>{e.name}</p>
                                    <p>{e.new_price}</p>
                                    <button className='cartitems_quantity'>{CartItems[e.id]}</button>
                                    <p>{e.new_price * CartItems[e.id]}</p>
                                    <img src={remove_icon} onClick={() => removeFromCart(e.id)} alt='' />
                                </div>
                                <hr />
                            </div>
                        
                    }
                    return null; // Ensures map always returns something
                })
            ) : (
                <p>Loading products...</p>
            )}
        </div>
    );
};

export default CartItems;



